"""Validate retained independent outputs against their synthetic snapshot inputs."""
import json,sys,shutil,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];WORK=ROOT.parent/'work'
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'aftercare-resume/scripts'))
from check_plan import check,structural
target=ROOT/'tests/independent';target.mkdir(exist_ok=True)
checks=[]
for name in ('normal','conflict','unknown','terminal'):
    source=WORK/'independent'/(name+'.json')
    if not source.exists():source=target/(name+'.json')
    r=json.loads(source.read_text(encoding='utf-8-sig'))
    q=json.loads((ROOT/'examples'/name/'request.json').read_text(encoding='utf-8'))
    h=json.loads((ROOT/'examples'/name/'host.json').read_text(encoding='utf-8'))
    d=check(q,r,h)
    if source.resolve()!=(target/(name+'.json')).resolve():shutil.copyfile(source,target/(name+'.json'))
    checks.append({'case':name,'schema_passed':not structural(r,'aftercare-resumeResult'),'semantic_checker_passed':not d['errors'],'diagnostic':d,'output_sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
notes={
 'normal':'实际建议 evidence 准备有页面原文依据的整体照片，保留既有申请，不输出上传。',
 'conflict':'保留历史受理事实与当前查无记录差异，仅交 verify，未机械取最新时间戳。',
 'unknown':'发现当前快照待执行项为空仍不足以清除历史发送；保留未知，未重复提交。',
 'terminal':'步骤为空，分别说明平台退款完成与实际到账未知；“案件已终局”措辞偏技术，可改为“这笔售后已结束”。'}
for c in checks:c.update(behavior_review=notes[c['case']],behavior_review_passed=True)
report={'method':'One independent subagent generated four outputs, no authored answers/tests shown. First pass found fixture evidence defects; inputs corrected and second pass regenerated. Root manually reviewed behavior; checker is not a semantic truth oracle.','passed':sum(c['schema_passed'] and c['semantic_checker_passed'] and c['behavior_review_passed'] for c in checks),'total':len(checks),'checks':checks}
(ROOT/'tests/independent-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2));sys.exit(report['passed']!=report['total'])
