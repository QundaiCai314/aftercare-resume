"""Authored snapshot tests and adversarial mutations, not model success rates."""
import copy
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'aftercare-resume/scripts'))
from check_plan import check, structural, SCHEMA
from build_cases import build, step
checks=[]
def record(category,name,ok,detail=None):checks.append(dict(category=category,name=name,passed=bool(ok),detail=detail))
def run(c):return check(c['request'],c['result'],c['host'])
cases=build()
for c in cases:
    before=copy.deepcopy(c);d=run(c)
    record('schema',str(c['id']),not structural(c['request'],'aftercare-resumeRequest') and not structural(c['result'],'aftercare-resumeResult'))
    record('authored_snapshot_behavior',str(c['id'])+':'+c['name'],not d['errors'] and d['planning_disposition']==c['expected_disposition'],d)
    record('side_effects_and_repeat',str(c['id']),before==c and d==run(c) and not d['automatic_execution_allowed'])
    if c['host']['changes']:
        bad=copy.deepcopy(c);bad['result']['data']['mismatches']=[]
        record('comparison',str(c['id'])+':missing_difference',bool(run(bad)['errors']))
    bad=copy.deepcopy(c);bad['result']['data']['historical_consent_reusable']=True
    record('authorization',str(c['id'])+':no_historical_consent',bool(run(bad)['errors']))

base=cases[0]
def negative(name,fn,category='semantic_mutations',start=base):
    c=copy.deepcopy(start);fn(c);d=run(c)
    record(category,name,bool(d['errors']) and d['planning_disposition']=='hold',d)
negative('response_call',lambda c:c['result'].update(call_id='other'))
negative('response_task',lambda c:c['result'].update(task_id='other'))
negative('historical_revision_not_current',lambda c:c['result'].update(based_on_task_revision=6))
negative('current_revision_changed',lambda c:c['host'].update(current_revision=13))
negative('ref_artifact_revision',lambda c:c['request']['task_snapshot'].update(revision=12))
negative('wrong_ref_kind',lambda c:c['request']['inputs']['saved_task'].update(kind='OutcomeReport'))
negative('cross_task_reference',lambda c:c['host']['registry']['saved'].update(task_id='other'))
negative('missing_host',lambda c:c.update(host={}))
negative('snapshot_mode_changed',lambda c:c['host']['registry']['current']['data'].update(mode='self'))
negative('lineage_unproven',lambda c:c['host'].update(ancestors=[]))
negative('ledger_changed',lambda c:c['host'].update(ledger_revision=19))
negative('new_window_epoch',lambda c:c['host'].update(current_epoch=5))
negative('window_mutex',lambda c:c['host'].update(write_inflight=True))
negative('runtime_not_ready',lambda c:c['host'].update(runtime_ready=False))
negative('scope_revoked',lambda c:c['host']['registry']['saved'].update(accessible=False))
negative('selection_from_page',lambda c:c['host']['selection'].update(source='page'))
negative('purpose_from_history',lambda c:c['host']['user_request'].update(source='history'))
negative('same_name_different_order',lambda c:c['host']['identity']['current'].update(order='order-B'))
negative('wrong_latest_id',lambda c:c['result']['data'].update(latest_outcome_ref='old-outcome'))
negative('wrong_latest_revision',lambda c:c['host']['outcome_binding']['ref'].update(revision=90))
negative('outcome_wrong_producer',lambda c:c['host']['outcome_binding'].update(producer_skill='aftercare-interact'))
negative('outcome_rejected_by_verify_check',lambda c:c['host']['outcome_binding'].update(accepted=False))
negative('stale_outcome',lambda c:c['host']['outcome_binding'].update(valid_until='2026-09-27T11:00:00+08:00'))
negative('future_outcome',lambda c:c['host']['outcome_binding'].update(captured_at='2026-09-28T12:00:00+08:00'))
negative('cached_outcome',lambda c:c['host']['outcome_binding'].update(cached=True))
negative('page_repaint',lambda c:c['host'].update(page_revision=6))
negative('outcome_evidence_missing',lambda c:c['host']['registry']['outcome']['data'].update(evidence_refs=[]))
negative('evidence_cross_account',lambda c:c['host']['evidence']['ev-now']['identity'].update(account='account-B'))
negative('evidence_missing',lambda c:c['host']['evidence'].pop('ev-now'))
negative('invented_mismatch_citation',lambda c:c['result']['data']['mismatches'].append({'field':'x','previous_evidence_ref':'invented','current_evidence_ref':None,'resolution':'unknown'}))
negative('new_fields_in_v1',lambda c:c['result']['data'].update(continuation_allowed=True),'schema')
negative('host_inside_wire',lambda c:c['request']['inputs'].update(host={}),'schema')
negative('paused_is_not_mode',lambda c:c['request'].update(mode='paused'),'schema')
negative('multiple_steps',lambda c:c['result']['data'].update(next_steps=[step('aftercare-interact'),step('aftercare-evidence')]))
negative('view_cannot_start',lambda c:(c['host']['user_request'].update(purpose='view'),c['host'].update(allowed_next_skills=['aftercare-interact']),c['result']['data'].update(next_steps=[step('aftercare-interact')])) )
negative('replay_cannot_complete',lambda c:c['host'].update(replay_requested=True))
unknown=next(c for c in cases if c['id']==5)
negative('unknown_to_completed',lambda c:c['result'].update(status='completed',issues=[]),start=unknown)
negative('verified_event_cannot_clear_unknown',lambda c:(c['host']['registry']['ledger']['data']['events'].append({'event_id':'verified','occurred_at':'2026-09-27T11:10:00+08:00','event_type':'verified','execution_ref':'execution-1','evidence_refs':[]}),c['result'].update(status='completed',issues=[])),start=unknown)
success=next(c for c in cases if c['id']==4)
negative('partial_reconciliation',lambda c:c['host']['possible_execution_refs'].append('execution-2'),start=success)
negative('wrong_reconciliation_target',lambda c:c['host']['reconciliations'][0]['identity'].update(item='item-B'),start=success)
negative('nonexact_reconciliation',lambda c:c['host']['reconciliations'][0].update(association='possible'),start=success)
terminal=next(c for c in cases if c['id']==20)
negative('terminal_new_application',lambda c:(c['host'].update(allowed_next_skills=['aftercare-interact']),c['result']['data'].update(next_steps=[step('aftercare-interact')])),start=terminal)
# Demonstrate versions are separate, and new valid decisions are not overwritten by history.
record('version_domains','artifact9_current2_task12_ledger18',not run(base)['errors'])
record('current_selection','new_valid_record',not run(next(c for c in cases if c['id']==23))['errors'])
report={'method':'authored expected results + pure checker + mutations; synthetic snapshots only','passed':sum(x['passed'] for x in checks),'total':len(checks),'checks':checks}
(ROOT/'tests/results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'passed':report['passed'],'total':report['total'],'failures':[x for x in checks if not x['passed']]},ensure_ascii=False,indent=2))
sys.exit(report['passed']!=report['total'])
