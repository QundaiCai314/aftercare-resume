"""Standalone proposed v2 subset. Never modifies the central contract."""
import copy,json
from pathlib import Path
from jsonschema import Draft202012Validator
ROOT=Path(__file__).resolve().parents[1]
s=json.loads((ROOT/'aftercare-resume/references/resume.schema.json').read_text(encoding='utf-8'))
s['$id']='urn:aftercare:resume:candidate:2.0.0'
for n in ('aftercare-resumeRequest','aftercare-resumeResult'):s['$defs'][n]['properties']['contract_version']['const']='2.0.0'
p=s['$defs']['ResumePlan'];p['properties']['continuation_gate']={'enum':['hold','review_only','ready_for_host_review','terminal']};p['required'].append('continuation_gate')
m=p['properties']['mismatches']['items'];m['properties']['resolution_state']={'enum':['resolved','unresolved']};m['required'].append('resolution_state')
p['properties']['latest_outcome_ref']={'anyOf':[copy.deepcopy(s['$defs']['aftercare-resumeRequest']['properties']['inputs']['properties']['current_outcome']),{'type':'null'}]}
p['allOf']=[{'if':{'properties':{'mismatches':{'contains':{'properties':{'resolution_state':{'const':'unresolved'}},'required':['resolution_state']}}}},'then':{'properties':{'continuation_gate':{'const':'hold'}}}}, {'if':{'properties':{'continuation_gate':{'enum':['review_only','terminal']}}},'then':{'properties':{'next_steps':{'maxItems':0}}}}]
out=ROOT/'candidate';out.mkdir(exist_ok=True);(out/'resume-v2.schema.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
Draft202012Validator.check_schema(s)
v=Draft202012Validator({'$defs':s['$defs'],'$ref':'#/$defs/aftercare-resumeResult'})
r=json.loads((ROOT/'examples/conflict/result.json').read_text(encoding='utf-8'));r['contract_version']='2.0.0';r['data']['continuation_gate']='hold';r['data']['latest_outcome_ref']={'artifact_id':'outcome','kind':'OutcomeReport','revision':3}
for m in r['data']['mismatches']:m['resolution_state']='unresolved'
(out/'conflict-result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
checks=[{'name':'candidate_conflict_valid','passed':not list(v.iter_errors(r))}]
bad=copy.deepcopy(r);bad['data']['continuation_gate']='ready_for_host_review';checks.append({'name':'unresolved_cannot_ready','passed':bool(list(v.iter_errors(bad)))})
bad=copy.deepcopy(r);bad['data']['latest_outcome_ref']='outcome';checks.append({'name':'outcome_requires_revision','passed':bool(list(v.iter_errors(bad)))})
bad=copy.deepcopy(r);bad['data']['mismatches']=[];bad['data']['continuation_gate']='terminal';checks.append({'name':'terminal_no_steps','passed':bool(list(v.iter_errors(bad)))})
old=json.loads((ROOT/'aftercare-resume/references/resume.schema.json').read_text(encoding='utf-8'));ov=Draft202012Validator({'$defs':old['$defs'],'$ref':'#/$defs/aftercare-resumeResult'});checks.append({'name':'v1_rejects_candidate','passed':bool(list(ov.iter_errors(r)))})
(ROOT/'tests/candidate-results.json').write_text(json.dumps({'proposal_only':True,'checks':checks,'passed':sum(c['passed'] for c in checks),'total':len(checks)},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(checks)
assert all(c['passed'] for c in checks)
